<?php
// Load status
$status = get_status();

// Set operation type
$status->op = 'restore';

// Save status
unset($status->file);
set_status($status);

// Force refresh the list of disks
$disks = get_disks(TRUE);

// Get partition options
$options = get_part_options($disks, array(), '/iso9660|fat.*|ext\d|ntfs/');
?>

<h1>Restaurar</h1>
<h3>Primero: Elija la unidad origen</h3>
<p>Seleccione la unidad que contiene el archivo de copia de seguridad:</p>

<form id="riotec_form" class="form-horizontal">

  <ul id="riotec_tabs" class="nav nav-tabs" style="margin-bottom: 1em;">
    <li class="active"><a href="#local" data-toggle="tab">Este equipo</a></li>
    <li><a href="#cifs" data-toggle="tab">Unidad de red</a></li>
<!--    <li><a href="#nfs" data-toggle="tab">NFS</a></li> -->
    <li><a href="#ssh" data-toggle="tab">SSH</a></li>
    <li><a href="#ftp" data-toggle="tab">FTP</a></li>
  </ul>
  <div id="myTabContent" class="tab-content">

    <div class="tab-pane fade active in" id="local">
      <div class="form-group">
        <label class="col-sm-2 control-label">Disco local <a data-toggle="tooltip" title="El backup se encuentra en este equipo"><i class="fas fa-info-circle text-info"></i></a></label>
        <div class="col-sm-10">
<?php if (sizeof($options)>0) { ?>
	  <select class="form-control" name="local_part" id="local_part">
	<?php
	foreach ($options as $ov=>$od) print "<option value='$ov'>$od</option>";
	?>
	  </select>
<?php } else { ?>
          <p class="form-control-static text-muted"><i>No hay particiones locales de las que leer.</i></p>
<?php } ?>
	</div>
      </div>
    </div>

    <div class="tab-pane fade" id="cifs">
      <div class="form-group">
        <label class="col-sm-2 control-label">Lugar <a data-toggle="tooltip" title="Recurso compartido (SMB/CIFS)"><i class="fas fa-info-circle text-info"></i></a></label>
        <div class="col-sm-10">
          <div class="input-group">
	    <input class="form-control" id="cifs_location" name="cifs_location" placeholder="\\host\carpeta" type="text">
            <span class="input-group-btn">
              <button class="btn btn-info" type="button" onClick="shareSearch();" data-toggle="tooltip" title="Intentar encontrar recursos compartidos en la red"><i class="fas fa-search"></i> Buscar</button>
            </span>
          </div>
        </div>
      </div>
      <div class="form-group">
        <label class="col-sm-2 control-label">Dominio <a data-toggle="tooltip" title="Opcional: puede colocar un nombre de dominio para acceder a este recurso compartido"><i class="fas fa-info-circle text-info"></i></a></label>
        <div class="col-sm-10">
          <input class="form-control" id="cifs_domain" name="cifs_domain" placeholder="WORKGROUP" type="text">
        </div>
      </div>
      <div class="form-group">
        <label class="col-sm-2 control-label">Usuario <a data-toggle="tooltip" title="Opcional: nombre de usuario para acceder al recurso compartido"><i class="fas fa-info-circle text-info"></i></a></label>
        <div class="col-sm-4">
          <input class="form-control" id="cifs_username" name="cifs_username" placeholder="usuario" type="text">
        </div>
	<label class="col-sm-2 control-label">Password <a data-toggle="tooltip" title="Opcional: clave del recurso compartido"><i class="fas fa-info-circle text-info"></i></a></label>
        <div class="col-sm-4">
          <div class="input-group">
            <input type="password" class="form-control" id="cifs_password" name="cifs_password" placeholder="clave">
              <span class="input-group-btn">
                <button class="btn btn-info" type="button" onClick="togglePassword($('#cifs_password'), $(this));" data-toggle="tooltip" title="Mostrar clave"><i class="fas fa-eye"></i></button>
              </span>
          </div>
	</div>
      </div>
    </div>

<!--
    <div class="tab-pane fade" id="nfs">
      <div class="form-group">
        <label class="col-sm-2 control-label">Host <a data-toggle="tooltip" title="Hostname or IP address of the NFSv3 share"><i class="fas fa-info-circle text-info"></i></a></label>
        <div class="col-sm-10">
          <input class="form-control" id="nfs_host" name="nfs_host" placeholder="192.168.0.100" type="text">
        </div>
      </div>
      <div class="form-group">
        <label class="col-sm-2 control-label">Share <a data-toggle="tooltip" title="Exported NFS directory path"><i class="fas fa-info-circle text-info"></i></a></label>
        <div class="col-sm-10">
          <input class="form-control" id="nfs_share" name="nfs_share" placeholder="/home/user" type="text">
        </div>
      </div>
    </div>
-->

    <div class="tab-pane fade" id="ssh">
      <div class="form-group">
        <label class="col-sm-2 control-label">Host SSH<a data-toggle="tooltip" title="Hostname o IP del servidor SSH"><i class="fas fa-info-circle text-info"></i></a></label>
        <div class="col-sm-10">
          <input class="form-control" id="ssh_host" name="ssh_host" placeholder="192.168.0.100" type="text">
        </div>
      </div>
      <div class="form-group">
        <label class="col-sm-2 control-label">Carpeta <a data-toggle="tooltip" title="Opcional: carpeta a acceder luego de conectar"><i class="fas fa-info-circle text-info"></i></a></label>
        <div class="col-sm-10">
          <input class="form-control" id="ssh_folder" name="ssh_folder" placeholder="/home/usuario" type="text">
        </div>
      </div>
      <div class="form-group">
        <label class="col-sm-2 control-label">Nombre de usuario <a data-toggle="tooltip" title="Usuario de SSH"><i class="fas fa-info-circle text-info"></i></a></label>
        <div class="col-sm-4">
          <input class="form-control" id="ssh_username" name="ssh_username" placeholder="usuario" type="text">
        </div>
	<label class="col-sm-2 control-label">Password <a data-toggle="tooltip" title="clave de SSH"><i class="fas fa-info-circle text-info"></i></a></label>
        <div class="col-sm-4">
          <div class="input-group">
            <input type="password" class="form-control" id="ssh_password" name="ssh_password" placeholder="clave">
              <span class="input-group-btn">
                <button class="btn btn-info" type="button" onClick="togglePassword($('#ssh_password'), $(this));" data-toggle="tooltip" title="Mostrar clave"><i class="fas fa-eye"></i></button>
              </span>
          </div>
	</div>
      </div>
    </div>

    <div class="tab-pane fade" id="ftp">
      <div class="form-group">
        <label class="col-sm-2 control-label">Host o IP<a data-toggle="tooltip" title="El hostname o IP del servidor FTP"><i class="fas fa-info-circle text-info"></i></a></label>
        <div class="col-sm-10">
          <input class="form-control" id="ftp_host" name="ftp_host" placeholder="ftp.riotec.ar" type="text">
        </div>
      </div>
      <div class="form-group">
        <label class="col-sm-2 control-label">Nombre de usuario <a data-toggle="tooltip" title="Opcional: usuario FTP"><i class="fas fa-info-circle text-info"></i></a></label>
        <div class="col-sm-4">
          <input class="form-control" id="ftp_username" name="ftp_username" placeholder="usuario" type="text">
        </div>
	<label class="col-sm-2 control-label">Password <a data-toggle="tooltip" title="Opcional: clave del FTP"><i class="fas fa-info-circle text-info"></i></a></label>
        <div class="col-sm-4">
          <div class="input-group">
            <input type="password" class="form-control" id="ftp_password" name="ftp_password" placeholder="clave">
              <span class="input-group-btn">
                <button class="btn btn-info" type="button" onClick="togglePassword($('#ftp_password'), $(this));" data-toggle="tooltip" title="Mostrar clave"><i class="fas fa-eye"></i></button>
              </span>
          </div>
	</div>
      </div>
    </div>

  </div>

  <div class="form-group">
    <div class="col-sm-12 text-right">
      <button type="reset" class="btn btn-default" onClick="$('#content').load('procesar.php?page=welcome');">&lt; Regresar</button>
      <button type="submit" class="btn btn-warning">Continuar &gt;</button>
    </div>
  </div>

</form>

<script>

function togglePassword($e, $b) {
	var newtype = $e.prop('type')=='password'?'text':'password';
	$e.prop('type', newtype);
	$("i", $b).toggleClass("fa-eye fa-eye-slash");
}

function shareSearch() {
	bootbox.dialog({
		message: '<div class="text-center"><i class="fas fa-spin fa-circle-notch text-primary"></i><br>Escaneando recursos compartidos de red...</div>',
		closeButton: false
	});
	$.post("/ajax/nas-search.php", { type: "cifs" })
		.done(function(data) {
			bootbox.hideAll();
			bootbox.alert(data);
		});
}

$("#riotec_form").submit(function(event) {
	event.preventDefault();
	bootbox.dialog({
		message: '<div class="text-center"><i class="fas fa-spin fa-circle-notch text-primary"></i><br>Chequeando unidad de origen...</div>',
		closeButton: true
	});
	var vars = $('#riotec_form').serialize();
	var type = $('ul#riotec_tabs li.active a').attr('href');
	$.ajax({
		'url': '/ajax/mount-drive.php',
       		'type': 'POST',
		data: { type: type, vars: vars },
	})
	.done(function(data) {
		bootbox.hideAll();
		r = $.parseJSON(data);
		if (r['status']) {
			// Success: Proceed to next page
			$('#content').load('procesar.php?page=restore-2');
		} else {
			// Failure: Notify user of error
			bootbox.alert('<h3>Failed to access drive</h3><div class="alert alert-danger"><p><i class="fas fa-exclamation-triangle"></i> <b>Error: ' + r['error'] + '</b></p></div><p>Revisar configuracion e intentar nuevamente.</p>');
		}
	});
});

</script>
