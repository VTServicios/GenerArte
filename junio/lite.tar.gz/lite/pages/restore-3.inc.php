<?php
// Load status
$status = get_status();

// Force refresh the list of disks 
$disks = get_disks(TRUE);

// Get list of disk options
$disk_options = get_disk_options($disks);
if (sizeof($disk_options)==0) crash('ERROR FATAL: No se encuentran discos!');
?>

<h1>Restaurar</h1>
<h3>Elegir unidad destino</h3>
<p>Seleccionar el lugar en donde restaurar la copia de seguridad:</p>

<form id="riotec_form" class="form-horizontal">
  <fieldset>

    <div class="form-group">
      <label class="col-sm-2 control-label">Destino <a data-toggle="tooltip" title="La unidad conectada a esta computadora a la cual restaurarle los datos"><i class="text-info fas fa-info-circle"></i></a></label>
      <div class="col-sm-10">
        <select id="drive" class="form-control">
	<?php
	foreach ($disk_options as $ov=>$od) print "<option value='$ov'>$od</option>";
	?>
        </select>
      </div>
    </div>

    <div class="form-group">
      <div class="col-sm-12 text-right">
        <button type="reset" class="btn btn-default" onClick="$('#content').load('procesar.php?page=restore-2');">&lt; Regresar</button>
        <button type="submit" class="btn btn-warning">Continuar &gt;</button>
      </div>
    </div>

  </fieldset>
</form>

<script>
$("#riotec_form").submit(function(event) {
	event.preventDefault();
	var url = 'procesar.php?page=restore-4';
	var drive = $('#drive').val();
	var posting = $.post(url, { drive: drive });
	posting.done(function(data) {
		$("#content").html($(data));
	});
});
</script>
