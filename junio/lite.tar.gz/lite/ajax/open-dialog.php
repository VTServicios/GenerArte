<?php
require_once('../funciones.inc.php');

// How long to wait
set_time_limit(300);

// Attempt to mount given partition
switch ($_REQUEST['type']) {
case 'dir':
	$result = array('dir'=>'');
	$dir = sane_path($_REQUEST['dir']);
	$sel = trim(choose_dir($dir.'/'));
	if (strpos($sel, MOUNTPOINT)===FALSE) {
		// Oops, a folder outside the mountpoint was selected
		$result['error'] = 'Carpeta no ubicada en unidad destino';
	} else {
		// Remove the mountpoint prefix
		$result['dir'] = preg_replace('#^'.MOUNTPOINT.'#', '', $sel);
	}
	if (!is_dir($sel)) $result['error'] = 'No es una carpeta';
	break;
case 'file':
	$result = array('file'=>'');
	$file = sane_path($_REQUEST['file']);
	$sel = trim(choose_file($file));
	if (strpos($sel, MOUNTPOINT)===FALSE) {
		// Oops, a folder outside the mountpoint was selected
		$result['error'] = 'Archivo no ubicado en unidad destino';
	} else {
		// Remove the mountpoint prefix
		$result['file'] = preg_replace('#^'.MOUNTPOINT.'#', '', $sel);
	}
	if (!is_file($sel)) $result['error'] = 'No es un archivo';
	break;
default:
	$result['error'] = 'Tipo de dialogo invalido';
	break;
}


// Return JSON-formatted result
print json_encode($result);

?>
