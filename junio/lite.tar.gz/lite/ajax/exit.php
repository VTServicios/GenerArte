<?php
require_once('../funciones.inc.php');

// Exit the application
exit_app();

?>
