Arch Mono 
=========

This is a black and white theme for Plymouth, forked from "Arch-Breeze"
