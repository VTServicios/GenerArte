<?php
require_once('../functions.inc.php');

// Exit the application
exit_app();

?>
