<?php
require_once('../functions.inc.php');

$sharelist = search_network_shares();
$found = sizeof($sharelist);
if ($found==0) {
	print "<h2>No se econtraron unidades compartidas</h2>";
	print "<p>Se debeberan ingresar los detalles de red compartida manualmente.</p>";
	die();
}
?>

<h3>Se encontro <?php print "$found unidad compartida".($found==1?'':'s'); ?></h3>
<p>Eliga un recurso compartido de la siguiente lista:</p>
<div class="list-group">
	<?php
	foreach ($sharelist as $s) {
		print "  <button type='button' onClick='loadShare(\"".addslashes($s['location'])."\", \"".$s['domain']."\");' class='list-group-item'>".$s['location']."</button>";
	}
	?>
</div>

<script>
function loadShare(loc, dom) {
	$('#cifs_location').val(loc);
	$('#cifs_domain').val(dom);
	bootbox.hideAll();
}
</script>
