<?php
// Load status
$status = get_status();

// Nothing gets posted here. The drive should have been mounted
// in the previous step.

// Warn if bytes free is lower than this threshold:
define('FREE_SPACE_THRESHOLD', 100000000);

$u = get_usage();
?>

<h1>Resguardar</h1>
<h3>Cuarto (4/5): Elegir carpeta destino</h3>
<p>La unidad seleccionada tiene <?php print $u['free']; ?> de espacio disponible. Elegir una carpeta para guardar:</p>

<form id="riotec_form" class="form-horizontal">

  <div class="form-group">
    <label class="col-sm-2 control-label">Lugar <a data-toggle="tooltip" title="Carpeta para guardar el backup"><i class="fas fa-info-circle text-info"></i></a></label>
    <div class="col-sm-10">
      <div class="input-group">
        <input class="form-control" id="dir" name="dir" placeholder="/" type="text" value="<?php if (property_exists($status, 'dir')) print $status->dir; ?>">
        <span class="input-group-btn">
          <button class="btn btn-info" type="button" onClick="chooseDir();"><i class="fas fa-folder-open"></i> Elegir</button>
        </span>
      </div>
    </div>
  </div>

  <div class="form-group">
    <div class="col-sm-12 text-right">
      <button type="reset" class="btn btn-default" onClick="$('#content').load('action.php?page=backup-3');">&lt; Regresar</button>
      <button type="submit" class="btn btn-warning">Continuar &gt;</button>
    </div>
  </div>

</form>

<script>

<?php if ($u['free_bytes'] < FREE_SPACE_THRESHOLD) { ?>

$(document).ready(function(){
	bootbox.alert({
		message: '<h3>Advertencia de poco espacio</h3><p>Hay solo <?php print $u['free']; ?> libre en el destino elegido.</p>',
		closeButton: true
	});
});

<?php } ?>

function chooseDir() {
	bootbox.dialog({
		message: '<div class="text-center"><i class="fas fa-spin fa-circle-notch text-primary"></i><br>Esperando para la seleccion de carpeta...</div>',
		closeButton: true
	});
	$.post("/ajax/open-dialog.php", { type: "dir", dir: $('#dir').val() })
		.done(function(data) {
			bootbox.hideAll();
			r = $.parseJSON(data);
			$('#dir').val(r['dir']);
			if ((typeof r['error'] !== "undefined") && (r['error'] !== null)) {
				bootbox.alert('<h3>Carpeta elegida invalida</h3><p>'+r['error']+'. Una carpeta valida ha sido seleccionada.</p>');
			}
		});
}

$("#riotec_form").submit(function(event) {
	event.preventDefault();
	var dir = $('#dir').val();
	$.ajax({
		'url': 'action.php?page=backup-5',
       		'type': 'POST',
		data: { dir: dir },
	})
	.done(function(data) {
		$('#content').html(data);
	});
});

</script>
