<?php
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.
#

require_once('funciones.inc.php');

// Bienvenida -una vez-
if (!file_exists(ESTADO)) {
	system_notice(
		"RIOTEC LITE",
		"Herramientas adicionales se encuentran en el entorno operativo",
		"dialog-information"
	);
}

// Initiate variable storage - Un arreglazo el status que despues guarda en archivo ESTADO
$status = new stdClass();

// Set host details
$host_info = trae_info_host();
$status->ip = $host_info['ip'];
$status->hostname = $host_info['name'];

// Save status
set_status($status);

?>
<!doctype html>
<html lang="en">
  <head>
    <title>RIOTEC LITE</title>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="icon" type="image/png" href="favicon.png">
    <link rel="stylesheet" href="/assets/bootstrap-3.4.1/dist/css/bootstrap-custom.min.css">
    <link rel="stylesheet" href="/assets/fontawesome-free-5.12.1-web/css/fontawesome.min.css">
    <link rel="stylesheet" href="/assets/fontawesome-free-5.12.1-web/css/solid.min.css">
    <link rel="stylesheet" href="/assets/fontawesome-free-5.12.1-web/css/brands.min.css">
    <link rel="stylesheet" href="/assets/animate.css-4.1.0/animate.min.css">
  </head>
  <body>

<!-- Evitar menu contextual -sin boton derecho- -->
<script type='text/javascript'>
	document.oncontextmenu = function(){return false}
</script>

    <div id="flex-master">
      <div id="flex-header">
        <div class="logo"></div>
      </div>
      <div id="flex-body">

        <div id="content" class="container">

		</div>

      </div>


      <div id="flex-footer">
        <div class="row">
          <div class="col-xs-6">
	    <span class="small text-muted">RIOTEC <?php print get_version(); ?></span>
          </div>
	  <div class="col-xs-6 text-right">
	    <span class="small"><i class="fas fa-key icon-button text-primary" data-toggle="popover" title="Acceso via ConectArte" data-content="<span class='small'>IP <?php print (empty($status->ip)?' para conectarte':'<b>'.$status->ip.'</b>'); ?> con clave <code><?php print trim(file_get_contents(VNCPASS_FILE)); ?></code></span>"></i></span>
          </div>
        </div>
      </div>
    </div>

    <!-- Incluye archivos JS -->
    <script src="/assets/jquery-1.12.4/dist/jquery.min.js"></script>
    <script src="/assets/bootstrap-3.4.1/dist/js/bootstrap.min.js"></script>
    <script src="/assets/bootstrap-notify-3.1.3/dist/bootstrap-notify.min.js"></script>
    <script src="/assets/bootbox-5.4.0/dist/bootbox.min.js"></script>

    <script>
      $(document).ready(function(){

	// Set up popovers
	$('[data-toggle="popover"]').popover({
		container: "body",
		placement: "auto left",
		trigger: "hover click",
		html: true,
	});

	// Get current step and show page
	$("#content").load("procesar.php", function(responseTxt, statusTxt, xhr){
		if(statusTxt == "error") {
			bootbox.alert({
			size: "small",
				title: "Error cargando contenido",
				message: xhr.status + ": " + xhr.statusText,
			});
		}
	});

      });
    </script>

  </body>
</html>
